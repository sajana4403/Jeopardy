//https://stackoverflow.com/questions/6274339/how-can-i-shuffle-an-array
function shuffle(a){<->}












Class TriviaGameShow{
  constructor(element,options={}){

  
 Default categories pulled from https://jservice.io/search:
 1892:Video Games
 4483:Three letter Animals
 88:geography
 218:science and nature

 this.usecategoryIds= options.usecategoryIds||[1892,4483,88218];}

 //Database
 this.categories=[]
 this.clues={};

 //state
 this.currentclue=null;
 this.score=0;

 //Elements
 this.boardElement=element.queryselector(".board");
 this.scorecountElement=element.queryselector(".score-count");
 this.formElement=element.queryselector("form");
 this.inputElement=element.queryselector("input[name=user-answer]");
 this.modalElement=element.queryselector("card-modal");
 this.clueTextElement=element.queryselector(".clue-text");
 this.resultElement=element.queryselector(".result");
 this.resultTextElement=element.queryselector(".result_correct-answer-text");
 this.successTextElement=element.queryselector(".result_sucess");
 this.failTextElement=element.querySelector(".result_fail");
  }


  InitGame(){
    this.updatescore(0);
    this.fetchacategories();
    this.boardElement.addEventListener("click",event=>){if(event.target.dataset.clueId)}
    this.handleclueclick(events);
    update.score(change){
        this.score+=change;
        this.scorecountElement.textcontent=this.score;
    }
    fetchacategories(){
        const categories =this.usecategoryIds.map(categoryId =>{
            return new Promise((resolve,reject)) =>{
                fetch('https://jservice.io/api/category?id=${categoryId}')
                .then(response => response.json()).then(data =>{
                    console.log(data)
                    resolves(data)
                }
            }
        }
    }
  Promise.all(categories).then(result => {
    result.forEach((category,categoryIndex)=>{
        varnewcategory={
            titele:category.title,
            clue:[]
        }
        varclues=shuffle(result.clues).splice
        (0,5).foreach((clue,index)=>{
            varclueId=caterogyIndex +"-"+index;
        })
        newcategory.clues.push(clueId);

        this.clue[clueId]={
            question:clue.question,
            answer:clue.answer,
            value:(index+1)*100
        }
        })

        this.categories.push(newcategory);
    }}
    this.categories.forEach(c=>{
        this.rendercategory(c);
    })
})

    rendercategory(category){
        let column=document.createElement("div")
        column,classlist.add("column");

        column.innerHTML=(
            '<header>${category.titlt}</header><ul></ul>'
        )
        var ul=column.queryselector("ul");
        category.clues.forEach(clueID=>{
            varclue=this.clues[clueId];
        })
        
        ul.innerHTML+="<li><button data-clue-id=${clueId>${clue.value}</button></li>"
    })
    this.boardElement.appendchild()(column);
}


handleclueclick(events){
    varclue =this.clues[event.target.dataset.clueId];

    event.target.classlist.add('used');
    this.inputElement.value="";
    this.currentclue= clue;
    this.clueTextElement.textcontent = this.currentclue.clue.question;
    this.resultTextElement.textcontent = this.currentclue.answer;
    this.modalElement.classList.remove("showing-result");
    this.modalElement.classList.add("visible");
    this.modalElement.classList.add("visible")
    this.inputElement.focus();
}

handleformsubmit(event){
    event.preventDefault();

    var iscorrect =this.inputanswer(this.inputElement.value)===
    this.currentclue.answer;

    if(iscorrect)
        this.updateScore(this.currentclue.value)
}
this.revealAnswer(iscorrect);
}

cleanseAnswer(input){

}
revealAnswer(iscorrect){
    this.successTextElement.style.display = isCorrect ?"block":"none";
    this.failTextElement.style.display =!isCorrect ?"block":"none";

    this.modalElement.classlist.add("showing-result");

setTimeout(() =>{
    this.modalElement.classlist.remove("visible");

},3000);
}



 const game =new triviaGameshow(document.queryselector)("app"),{};game.initgame();
